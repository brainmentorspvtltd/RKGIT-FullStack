package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public class RyuPlayer implements GameConstants {
	
	private int x;
	private int y;
	private int w;
	private int h;
	private int state;
	private BufferedImage playerImage ;
	private BufferedImage[] loadImages = new BufferedImage[6];
	private BufferedImage[] punchImages = new BufferedImage[6]; 
	
	public void setState(int state) {
		this.state = state;
	}
	public RyuPlayer() {
		loadImage();
		x = 100;
		h = 250;
		w = 250;
		state = DEFAULT;
		y = FLOOR - h;
		loadDefaultMove();
		loadPunch();
	}
	
	private void loadPunch() {
		
		punchImages[0] = playerImage.getSubimage(25, 818, 71, 102);
		punchImages[1] = playerImage.getSubimage(105, 815, 75, 106);
		punchImages[2] = playerImage.getSubimage(188, 816, 116, 106);
		punchImages[3] = playerImage.getSubimage(309, 814, 83, 105);
		punchImages[4] = playerImage.getSubimage(403, 814, 107, 109);
		punchImages[5] = playerImage.getSubimage(515, 820, 82, 101);
	}
	
	private void loadDefaultMove() {
		loadImages[0] = playerImage.getSubimage(62, 235, 73, 103);
		loadImages[1] = playerImage.getSubimage(141, 230, 74, 105);
		loadImages[2] = playerImage.getSubimage(224, 231, 67, 103);
		loadImages[3] = playerImage.getSubimage(302, 231, 62, 104);
		loadImages[4] = playerImage.getSubimage(374, 232, 66, 100);
		loadImages[5] = playerImage.getSubimage(454, 234, 67, 104);
		
		
	}
	private int imageIndex;
	private BufferedImage printDefaultMove(BufferedImage images[]) {
		
		if(imageIndex>5) {
			imageIndex = 0;
			System.out.println("Inside If index "+imageIndex + " State "+state);
			state = DEFAULT;
		}
		BufferedImage currentImage = images[imageIndex]; 
		imageIndex ++;
		
		return currentImage;
	}
	
	public void paintPlayer(Graphics brush) {
		if(state == PUNCH) {
			
			brush.drawImage(printDefaultMove(punchImages),x,y,w,h , null);
		}
		else {
		brush.drawImage(printDefaultMove(loadImages),x,y,w,h , null);
		}
	}
	
	private BufferedImage standing() {
		return playerImage.getSubimage(454, 238, 68, 96);
	}
	
	private void loadImage() {
		try {
		playerImage = ImageIO.read(RyuPlayer
				.class.
				getResource(RYU_PLAYER_IMAGE));
		}
		catch(IOException ex) {
			System.out.println("Player Image Not Found...");
			System.exit(0);
		}
	}
	

}
