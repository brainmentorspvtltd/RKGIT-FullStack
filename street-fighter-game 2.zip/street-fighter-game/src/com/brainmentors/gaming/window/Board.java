package com.brainmentors.gaming.window;

import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.sprites.RyuPlayer;
import com.brainmentors.gaming.utils.GameConstants;

// Painting
public class Board extends JPanel implements GameConstants {
	BufferedImage backgroundImage;
	RyuPlayer ryu ;
	
	public Board() {
		loadBackground();
		ryu = new RyuPlayer();
		setFocusable(true);
		bindEvents();
		gameLoop();
	}
	
	private void bindEvents() {
		this.addKeyListener(new KeyAdapter() {
			
			
			
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyCode()==KeyEvent.VK_P) {
					ryu.setState(PUNCH);
				}
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	
	private void loadBackground() {
		try {
			// throw new IOException(); // Implicit throw
		backgroundImage =ImageIO.
				read(Board.class.
						getResource(BACKGROUND_IMAGE_NAME));
		}
		catch(IOException e) {
			System.out.println("OOPS Something Went Wrong...");
			System.exit(0);
		}
	}
	Timer timer ;
	private void gameLoop() {
		// Start  a New Thread
		timer =  new Timer(90,   ( x)->{
			repaint();
		});
		timer.start();
	}
	
	// Need a Thread
	// Thread - Code in Execution is called Thread
	// e.g main Thread (Stack)
	// Per Thread Per Stack
	
	@Override
	public void paintComponent(Graphics brush) {
		super.paintComponent(brush);
		brush.drawImage(backgroundImage, 0,0, GWIDTH, GHEIGHT, null);
		ryu.paintPlayer(brush);
	}
}
