package com.brainmentors.streetfighter.utils;

public interface GameConstants {
 int GWIDTH = 1400;
 int GHEIGHT = 900;
 String TITLE = "Street Fighter Game";
 String GAME_BACKGROUND = "bg.jpeg";
		 
}
