package com.brainmentors.streetfighter.views;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.brainmentors.streetfighter.sprites.Player;
import com.brainmentors.streetfighter.utils.GameConstants;

public class Board extends JPanel implements GameConstants{
	BufferedImage backgroundImage ;
	Player player;
	public Board() {
		player = new Player();
		try {
			
			backgroundImage= ImageIO
					.read(Board.class.getResource
							(GAME_BACKGROUND));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void paintComponent(Graphics brush) {
		super.paintComponent(brush);
		brush.drawImage(backgroundImage,0,0,GWIDTH,GHEIGHT,null);
			player.drawPlayer(brush);
		}

}
