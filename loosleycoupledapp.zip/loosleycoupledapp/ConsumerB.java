public class ConsumerB {
    public static void main(String[] args) {
        IProducer producer = Factory.getInstance();
        // IProducer producer = new Producer();
        producer.show();
        //producer.
    }
}
