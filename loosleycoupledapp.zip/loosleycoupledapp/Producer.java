class Producer implements IProducer{
    @Override
    public void show(){
        System.out.println("Producer Show");
        dontExpose(10, 20);
        newShow();
    }
    public void dontExpose(int x, int y){
        System.out.println("Producer Dont Expose...");
    }

    public void newShow(){

    }
}