public class ConsumerA {
    public static void main(String[] args) {
        IProducer producer = Factory.getInstance();
        //IProducer producer = new Producer();
        producer.show();
        //producer.show();
        //producer.dontExpose();
    }
}
