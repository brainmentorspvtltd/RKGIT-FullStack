public class EnhanceProducer implements IProducer{

    @Override
    public void show() {
       System.out.println("Better Show by Enhance producer...");
       print();
    }

    public void print(){
        System.out.println("I am Print...");
    }
    
}
