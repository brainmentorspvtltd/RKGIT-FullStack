package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public class RyuPlayer implements GameConstants {
	
	private int x;
	private int y;
	private int w;
	private int h;
	private BufferedImage playerImage ;
	
	public RyuPlayer() {
		loadImage();
		x = 100;
		h = 200;
		w = 200;
		y = FLOOR - h;
	}
	
	public void paintPlayer(Graphics brush) {
		brush.drawImage(standing(),x,y,w,h , null);
	}
	
	private BufferedImage standing() {
		return playerImage.getSubimage(454, 238, 68, 96);
	}
	
	private void loadImage() {
		try {
		playerImage = ImageIO.read(RyuPlayer
				.class.
				getResource(RYU_PLAYER_IMAGE));
		}
		catch(IOException ex) {
			System.out.println("Player Image Not Found...");
			System.exit(0);
		}
	}
	

}
