package com.brainmentors.gaming.utils;

public interface GameConstants {
	int GHEIGHT = 900; // public static final int GHEIGHT = 900;
	int GWIDTH = 1200;
	String TITLE = "Street Fighter Game";
	String BACKGROUND_IMAGE_NAME = "game-bg.jpeg";
	String RYU_PLAYER_IMAGE = "player-sprite.gif";
	int FLOOR = GHEIGHT - 100;
}
