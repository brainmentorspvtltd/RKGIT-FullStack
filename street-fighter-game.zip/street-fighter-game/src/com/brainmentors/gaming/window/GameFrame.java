package com.brainmentors.gaming.window;

import javax.swing.JFrame;

import com.brainmentors.gaming.utils.GameConstants;

public class GameFrame extends JFrame implements GameConstants {
	
	public GameFrame() {
		Board board =new Board();
		add(board);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(GWIDTH,GHEIGHT);
		setResizable(false);
		setTitle(TITLE);
		setLocationRelativeTo(null);
		setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameFrame obj = new GameFrame();

	}

}
