package com.brainmentors.gaming.window;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.brainmentors.gaming.sprites.RyuPlayer;
import com.brainmentors.gaming.utils.GameConstants;

// Painting
public class Board extends JPanel implements GameConstants {
	BufferedImage backgroundImage;
	RyuPlayer ryu ;
	
	public Board() {
		loadBackground();
		ryu = new RyuPlayer();
	}
	private void loadBackground() {
		try {
			// throw new IOException(); // Implicit throw
		backgroundImage =ImageIO.
				read(Board.class.
						getResource(BACKGROUND_IMAGE_NAME));
		}
		catch(IOException e) {
			System.out.println("OOPS Something Went Wrong...");
			System.exit(0);
		}
	}
	
	@Override
	public void paintComponent(Graphics brush) {
		super.paintComponent(brush);
		brush.drawImage(backgroundImage, 0,0, GWIDTH, GHEIGHT, null);
		ryu.paintPlayer(brush);
	}
}
