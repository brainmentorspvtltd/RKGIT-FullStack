package com.brainmentors.gaming.sprites;



import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public class KenPlayer implements GameConstants  {
	private int x;
	private int y;
	private int w;
	private int h;
	private int state;
	private BufferedImage playerImage ;
	
	
	
	public int getX() {
		return x;
	}


	public void setX(int x) {
		this.x = x;
	}


	public int getY() {
		return y;
	}


	public void setY(int y) {
		this.y = y;
	}


	public int getW() {
		return w;
	}


	public void setW(int w) {
		this.w = w;
	}


	public int getH() {
		return h;
	}


	public void setH(int h) {
		this.h = h;
	}


	public KenPlayer()  {
		x = GWIDTH - 500;
		w = 250;
		h=250;
		y = FLOOR - h;
		
		
		loadImage();
		
	}
	
	
	private void loadImage() {
		try {
		playerImage = ImageIO.read(KenPlayer
				.class.
				getResource(KEN_PLAYER_IMAGE));
		}
		catch(IOException ex) {
			System.out.println("Ken Player Image Not Found...");
			System.exit(0);
		}
	}
	
	
	
	
	
	
	public void paintPlayer(Graphics brush) {
		
		BufferedImage subImage = playerImage.getSubimage(1756,685,62,94);
		brush.drawImage(subImage,x,y,w,h , null);
		
	}
	
}

