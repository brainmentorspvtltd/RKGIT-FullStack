package com.brainmentors.gaming.window;

import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.sprites.KenPlayer;
import com.brainmentors.gaming.sprites.RyuPlayer;
import com.brainmentors.gaming.utils.GameConstants;

// Painting
public class Board extends JPanel implements GameConstants {
	BufferedImage backgroundImage;
	RyuPlayer ryu ;
	KenPlayer ken;
	boolean isCollideFlag;
	public Board() {
		loadBackground();
		ryu = new RyuPlayer();
		ken = new KenPlayer();
		setFocusable(true);
		bindEvents();
		gameLoop();
	}
	
	
	private boolean isCollide() {
		
		int xDistance = Math.abs(ryu.getX() - ken.getX());
		int yDistance = Math.abs(ryu.getY() - ken.getY());
		int maxH = Math.max(ryu.getH(), ken.getH());
		int maxW = Math.max(ryu.getW(), ken.getW());
		return xDistance<=(maxW-40) && yDistance<=maxH;
	}
	
	private void bindEvents() {
		this.addKeyListener(new KeyAdapter() {
			
			
			
			@Override
			public void keyReleased(KeyEvent e) {
				ryu.setSpeed(0);
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if(e.getKeyCode() == KeyEvent.VK_SPACE) {
					ryu.jump();
				} else
				if(e.getKeyCode()==KeyEvent.VK_P) {
					ryu.setState(PUNCH);
					ryu.setImageIndex(0);
				}
				else if(e.getKeyCode() == KeyEvent.VK_K) {
					ryu.setState(KICK);
					ryu.setImageIndex(0);
				}
				else if(e.getKeyCode()==KeyEvent.VK_RIGHT && !isCollideFlag) {
					ryu.setSpeed(5);
				}
				else if(e.getKeyCode()==KeyEvent.VK_LEFT ) {
					ryu.setSpeed(-5);
				}
				
			}
		});
	}
	
	private void loadBackground() {
		try {
			// throw new IOException(); // Implicit throw
		backgroundImage =ImageIO.
				read(Board.class.
						getResource(BACKGROUND_IMAGE_NAME));
		}
		catch(IOException e) {
			System.out.println("OOPS Something Went Wrong...");
			System.exit(0);
		}
	}
	
	public void collision() {
		if(isCollide()) {
			isCollideFlag = true;
			System.out.println("Collide....");
			ryu.setSpeed(0);
		}
	}
	
	Timer timer ;
	private void gameLoop() {
		// Start  a New Thread
		timer =  new Timer(40,   ( x)->{
			ryu.move();
			ryu.fall();
			collision();
			repaint();
		});
		timer.start();
	}
	
	// Need a Thread
	// Thread - Code in Execution is called Thread
	// e.g main Thread (Stack)
	// Per Thread Per Stack
	
	@Override
	public void paintComponent(Graphics brush) {
		super.paintComponent(brush);
		brush.drawImage(backgroundImage, 0,0, GWIDTH, GHEIGHT, null);
		ryu.paintPlayer(brush);
		ken.paintPlayer(brush);
	}
}
